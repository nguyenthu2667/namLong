const CopyWebpackPlugin = require('copy-webpack-plugin')

module.exports = {
  publicPath: process.env.NODE_ENV === 'production' ? '/' : '/',
  chainWebpack: (config) => {
    console.log(1, 'chainWebpack', config)
    // process.env.NODE_ENV === 'production'
    //   ? config.externals(['@vue/composition-api'])
    //   : {}
    //BUG-NPM RUN BUILD
  },
  css: {
    extract: false,
  },
  configureWebpack: {
    plugins: [
      new CopyWebpackPlugin([
        { from: 'src/assets/img', to: 'assets/img' },
        { from: 'src/assets/fonts', to: 'assets/fonts' },
      ]),
    ],
  },
}
