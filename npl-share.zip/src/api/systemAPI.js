import axiosClient from './index'

const systemAPI = {
  getLanguages: () => {
    const url = '/api/config/ChoseLanguage'
    return axiosClient.post(url)
  },
  getMenus: (body) => {
    const url = '/api/menu/GetMenuRightByGroupID'
    return axiosClient.post(url, body)
  },
}

export default systemAPI
