import axiosClient from './index'

const userAPI = {
  login: (body) => {
    const url = '/api/authentication/LoginUser'
    return axiosClient.post(url, body)
  },
}

export default userAPI
