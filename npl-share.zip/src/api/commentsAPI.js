import axiosClient from './index'

const commentsAPI = {
  add: (body) => {
    const url = '/api/TreeComments/Add'
    return axiosClient.post(url, body)
  },
}

export default commentsAPI
