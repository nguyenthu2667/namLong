import Axios from 'axios'
import queryString from 'query-string'
import { LANGUAGE } from '../directives/contants'
import moment from 'moment'

const KEY = window.btoa(
  'NLTGroup2020@!#|' + moment(new Date()).format('YYYY-MM-DD HH:mm:ss'),
)
// console.log(1, "KEY", KEY, 'NLTGroup2020@!#|' + moment(new Date()).format('YYYY-MM-DD HH:mm:ss'))
const TIMER = 3000
const BASE_URL = 'https://apidev.namlongtekgroup.com'
const HEADER = {
  accept: 'text/plain',
  'Content-Type': 'application/json-patch+json',
  Language: LANGUAGE,
  'Cache-Control': 'no-cache',
  PublicKey: KEY,
}

//main api
const axiosClient = new Axios.create({
  baseURL: BASE_URL,
  timeout: TIMER,
  headers: HEADER,
  paramsSerializer: (params) => queryString.stringify(params),
})
//handle request
axiosClient.interceptors.request.use(async (request) => {
  request.headers.Language = LANGUAGE
  request.headers.Authorization =
    'Bearer ' + localStorage.getItem('token') || ''
  return request
})
//handle response
axiosClient.interceptors.response.use(
  //gọi thành công
  (response) => {
    if (
      response.data &&
      response.data.ErrorCode == 0 &&
      response.data.StatusCode == 200 &&
      response.data.Result
    ) {
      let obj = {
        status: true,
        message: response.data.Message,
        data: response.data.Result,
      }
      return obj
    } else {
      let obj = {
        status: false,
        message: response.data.Message,
        data: null,
      }
      return obj
    }
  },
  //gọi thất bại
  (error) => {
    if (error.request.status === 0) {
      return Promise.reject(error.message)
    }
    if (error.response.status === 401 || error.request.status === 401) {
      let user = JSON.parse(localStorage.getItem('user'))
      axiosClient
        .post(
          BASE_URL + '/api/authentication/RefreshToken',
          {
            refreshToken: user.RefreshToken,
          },
          {
            baseURL: BASE_URL,
            timeout: TIMER,
            headers: HEADER,
            paramsSerializer: (params) => queryString.stringify(params),
          },
        )
        .then((response) => {
          if (
            response.data &&
            response.data !== '' &&
            response.data.StatusCode === 200 &&
            response.data.Success === 1
          ) {
            localStorage.setItem('token', response.data.Result.Token)
            let users = {
              Avatar: user.Avatar,
              CreateDate: user.CreateDate,
              GroupDescription: user.GroupDescription,
              GroupID: user.GroupID,
              GroupName: user.GroupName,
              RefreshToken: response.data.Result.RefreshToken,
              Token: response.data.Result.Token,
              UserAddress: user.UserAddress,
              UserDescription: user.UserDescription,
              UserEmail: user.UserEmail,
              UserFullName: user.UserFullName,
              UserID: user.UserID,
              UserName: user.UserName,
              UserPhone: user.UserPhone,
            }
            localStorage.setItem('user', JSON.stringify(users))
            Axios.defaults.headers.common['Authorization'] =
              'Bearer ' + response.data.Result.Token
            location.reload()
          } else {
            localStorage.removeItem('user')
            localStorage.removeItem('token')
            delete Axios.defaults.headers.common['Authorization']
            location.reload()
          }
        })
        .catch((error) => {
          console.log('RefreshToken Catch => ', error.message)
        })
    }

    return Promise.reject(error.message)
  },
)

export default axiosClient
