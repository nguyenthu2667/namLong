import axiosClient from './index'

const mapAPI = {
  getDataByCODE: (body) => {
    const url = '/api/TreeCustomers/GetMapNow_Customer'
    return axiosClient.post(url, body)
  },
}

export default mapAPI
