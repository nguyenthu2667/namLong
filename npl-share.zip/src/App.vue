<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App',
  data: () => ({}),
  created() {},
}
</script>

<style lang="scss" src="./App.scss"></style>
