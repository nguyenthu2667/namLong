import Vue from 'vue'
import VueRouter from 'vue-router'
import store from '../store/index'
Vue.use(VueRouter)

const Login = () => import('@/views/auth/Login.vue')
const Page404 = () => import('@/views/Page404.vue')
const Main = () => import('@/layout/Wrapper.vue')
const Admin = () => import('@/views/main/Index')
//dashboards
const Dashboards = () => import('@/views/main/dashboards/Index.vue')
const Monitor = () => import('@/views/main/dashboards/monitor/Dashboard.vue')
const Aqua = () => import('@/views/main/dashboards/aqua/Dashboard.vue')
//configs
const MenuSystem = () => import('@/views/main/configs/system/MenuSystem.vue')
//security
const DataLayer = () =>
  import('@/views/main/security/data-authorization/DataLayer.vue')
//category
const ImportTemplate = () => import('@/views/main/categorys/ImportTemplate.vue')
//map
const Map = () => import('@/views/main/map/Map.vue')

const Test = () => import('@/views/Test.vue')

const routes = [
  {
    path: '/',
    component: Main,
    redirect: '/map',
    children: [
      {
        name: 'map',
        path: 'map',
        component: Map,
      },
      {
        path: 'dashboards',
        component: Dashboards,
        children: [
          { path: 'monitor-follow', component: Monitor },
          { path: 'aquaculture', component: Aqua },
        ],
      },
    ],
  },
  {
    path: '/login',
    component: Login,
  },
  {
    path: '*',
    component: Page404,
  },
  {
    path: '/test',
    component: Test,
  },
]

const router = new VueRouter({
  linkActiveClass: 'active',
  routes,
  mode: 'history',
})

router.beforeEach((to, from, next) => {
  if (to.matched.some((record) => record.meta.requiresAuth)) {
    if (store.getters.currentUser) {
      next()
      return
    } else {
      next('/login')
    }
  }
  next()
})

export default router
