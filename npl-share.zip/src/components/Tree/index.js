import Tree from './Tree'
import './style.scss'
export default Tree
