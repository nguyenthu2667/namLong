<template>
  <div class="modal-toolbar">
    <div class="header-modal-toolbar d-flex pr-2 pt-2 pb-2 bg-light">
      <div class="w-100 drag" style="font-size: 1.2rem;">
        <b>
          <i class="fad fa-arrows"></i>
          <span class="ml-2">
            <b>{{ $t('tab.feedback').toUpperCase() }}</b>
          </span>
        </b>
      </div>
      <div class="w-10 text-right" style="position: relative;">
        <b-button
          class="btn-remove"
          style="
            position: absolute;
            top: -8px;
            right: -8px;
            padding: 3px;
            padding-bottom: 0;
            background: #e9ecef;
            border: 0;
          "
          variant="danger"
          @click="$modal.hide(name)"
        >
          ❌
        </b-button>
      </div>
    </div>
    <tree-feed-back :id="0"></tree-feed-back>
  </div>
</template>

<script>
import TreeFeedBack from '@/views/main/map/components/TreeFeedBack'

export default {
  props: ['name', 'data', 'reload'],
  name: 'modal-toolbar',
  components: {
    'tree-feed-back': TreeFeedBack,
  },
}
</script>

<style lang="scss" scoped>
.modal-toolbar {
  padding: 10px;
}
.btn-remove:hover {
  transform: scale(1.2);
}
</style>
