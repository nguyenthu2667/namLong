<template>
  <div>
    <div class="aselect" :data-value="currentValue" :data-list="list">
      <div class="selector" @click="toggle()">
        <div class="label">
          <span>{{ currentValue }}</span>
        </div>
        <div class="arrow" :class="{ expanded: visible }"></div>
        <div :class="{ hidden: !visible, visible }">
          <ul>
            <li
              :class="{ current: item === currentValue }"
              v-for="(item, i) in list"
              @click="select(item)"
              :key="i"
            >
              {{ item }}
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    value: { type: String, default: null },
    option: { type: Array, default: null },
  },
  data() {
    return {
      currentValue: this.value ?? 'current-value',
      list: this.option ?? ['Orange', 'Apple', 'Kiwi', 'Lemon', 'Pineapple'],
      visible: false,
    }
  },
  methods: {
    toggle() {
      this.visible = !this.visible
    },
    select(option) {
      this.currentValue = option
    },
  },
}
</script>

<style lang="scss" scoped>
.aselect {
  .selector {
    border: 1px solid gainsboro;
    background: #f8f8f8;
    position: relative;
    z-index: 1;
    .arrow {
      position: absolute;
      right: 10px;
      top: 40%;
      width: 0;
      height: 0;
      border-left: 7px solid transparent;
      border-right: 7px solid transparent;
      border-top: 10px solid #888;
      transform: rotateZ(0deg) translateY(0px);
      transition-duration: 0.3s;
      transition-timing-function: cubic-bezier(0.59, 1.39, 0.37, 1.01);
    }
    .expanded {
      transform: rotateZ(180deg) translateY(2px);
    }
    .label {
      display: block;
      padding: 5px;
      font-size: 16px;
      color: #888;
    }
  }
  ul {
    width: 100%;
    list-style-type: none;
    padding: 0;
    margin: 0;
    font-size: 16px;
    border: 1px solid gainsboro;
    position: absolute;
    z-index: 1;
    background: #fff;
  }
  li {
    padding: 5px;
    color: #666;
    &:hover {
      color: white;
      background: seagreen;
    }
  }
  .current {
    background: #eaeaea;
  }
  .hidden {
    visibility: hidden;
  }
  .visible {
    visibility: visible;
  }
}
</style>
