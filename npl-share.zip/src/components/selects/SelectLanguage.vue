<template>
  <div>
    <div class="aselect" :data-value="currentValue" :data-list="list">
      <div class="selector" @click="toggle()">
        <div v-if="list && list.length > 0" class="label">
          <img
            style="width: 30px; height: 25px; background: #f3f3f3;"
            :src="list.find((e) => e.id == currentValue).icon"
            alt="icon"
          />
          <span>
            {{ list.find((e) => e.id == currentValue).label.toUpperCase() }}
          </span>
        </div>
        <div class="arrow" :class="{ expanded: visible }"></div>
        <div :class="{ hidden: !visible, visible }">
          <ul>
            <li
              :class="{ current: item === currentValue }"
              v-for="(item, i) in list"
              @click="select(item)"
              :key="i"
            >
              <img
                style="width: 30px; height: 25px;"
                :src="item.icon"
                alt="icon"
              />
              {{ item.label.toUpperCase() }}
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { LANGUAGE } from '@/directives/contants'
import systemAPI from '@/api/systemAPI.js'
export default {
  name: 'select-language',
  data() {
    return {
      currentValue: LANGUAGE,
      list: [],
      visible: false,
    }
  },
  async created() {
    await this.getDataOptionLanguage()
  },
  methods: {
    getDataOptionLanguage() {
      let array = []
      systemAPI
        .getLanguages()
        .then((res) => {
          let result = res.status ? res.data : null
          if (result?.length > 0) {
            this.list.length = 0
            result.forEach((e) => {
              let obj = {
                id: e.Code,
                label: e.LanguageName,
                icon: e.Icon,
              }
              this.list.push(obj)
              if (obj.id == this.keyLanguage) {
                this.value = obj
              }
            })
          }
        })
        .catch((err) => {
          console.log(err)
        })
      return array
    },
    toggle() {
      this.visible = !this.visible
    },
    select(option) {
      let id = option.id
      this.currentValue = id
      localStorage.setItem('currentLanguage', id)
    },
  },
}
</script>

<style lang="scss" scoped>
.aselect {
  .selector {
    border: 1px solid gainsboro;
    background: #f8f8f8;
    position: relative;
    z-index: 1;
    .arrow {
      position: absolute;
      right: 10px;
      top: 40%;
      width: 0;
      height: 0;
      border-left: 7px solid transparent;
      border-right: 7px solid transparent;
      border-top: 10px solid #888;
      transform: rotateZ(0deg) translateY(0px);
      transition-duration: 0.3s;
      transition-timing-function: cubic-bezier(0.59, 1.39, 0.37, 1.01);
    }
    .expanded {
      transform: rotateZ(180deg) translateY(2px);
    }
    .label {
      display: block;
      padding: 5px;
      font-size: 16px;
      color: #888;
    }
  }
  ul {
    width: 100%;
    list-style-type: none;
    padding: 0;
    margin: 0;
    font-size: 16px;
    border: 1px solid gainsboro;
    position: absolute;
    z-index: 1;
    background: #fff;
  }
  li {
    padding: 5px;
    color: #666;
    &:hover {
      color: white;
      background: seagreen;
    }
  }
  .current {
    background: #eaeaea;
  }
  .hidden {
    visibility: hidden;
  }
  .visible {
    visibility: visible;
  }
}
</style>
