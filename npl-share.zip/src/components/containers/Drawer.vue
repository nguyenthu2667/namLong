<template>
  <div class="vps-drawer">
  <slot></slot>
  </div>
</template>

<script>
export default {
  name: "vps-drawer",

  components: {}
};
</script>

<style>
</style>
