<template>
  <img
    height="64"
    width="64"
    class="img-responsive img-rounded"
    src="../assets/icons/tree/logo512.png"
    alt="User "
  />
</template>

<script>
export default {
  name: 'avatar',
}
</script>

<style></style>
