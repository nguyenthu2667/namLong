<template>
  <div>
    <b-row class="m-1 mt-3">
      <template v-if="process && process.length > 0">
        <b-col md="12" class="mb-2">
          <h5
            class="font-weight-bold"
            :style="'color:' + process[0].statusColor"
          >
            {{ process[0].name.toUpperCase() }}
          </h5>
          <h6 class="font-italic">
            Cập nhật
            <strong>
              {{ process[0].datetime }}
            </strong>
          </h6>
        </b-col>
        <b-col md="12">
          <ol class="numbered" :style="custom">
            <template v-for="(step, index) in process">
              <li :key="index">
                <h5
                  class="ont-weight-bold mb-2"
                  :style="{
                    color: step.statusColor,
                  }"
                >
                  {{ step.name }}
                </h5>
                <p class="font-italic">
                  {{ step.datetime }}
                </p>
                <hr />
              </li>
            </template>
          </ol>
        </b-col>
      </template>
      <template v-else>
        <b-col md="12">
          <div class="text-center drag bg-light">
            <img
              style="width: 100%; height: 100%;"
              src="https://store.vtctelecom.com.vn/Content/images/no-data.png"
            />
          </div>
        </b-col>
      </template>
    </b-row>
  </div>
</template>

<script>
export default {
  props: ['process'],
  name: 'process-step',
  data() {
    return {
      //   process: [
      //     {
      //       name: 'Hoàn thành',
      //       datetime: '10:30 30/6/2022',
      //       statusID: 1,
      //       statusColor: 'green',
      //     },
      //     {
      //       name: 'Đang xét duyệt',
      //       datetime: '10:30 30/6/2022',
      //       statusID: 0,
      //       statusColor: 'red',
      //     },
      //     {
      //       name: 'Khởi tạo',
      //       datetime: '10:30 30/6/2022',
      //       statusID: 0,
      //       statusColor: 'black',
      //     },
      //   ],
    }
  },
  computed: {
    custom() {
      if (this.process) {
        return 'counter-reset: numbered-list ' + (this.process.length + 1)
      }
    },
  },
}
</script>
<style lang="scss" scoped>
ol {
  list-style: none;
  margin: 0;
  padding: 0;
}

li {
  margin: 0;
  padding: 0;
}

body {
  background-color: #fff;
  margin: 100px;
  padding: 20px;
}

ol.numbered {
  $bullet-line-width: 3px;
  $bullet-color: grey;
  $bullet-border-width: $bullet-line-width;
  $bullet-background-color: white;
  $bullet-size: 25px;
  border-left: $bullet-line-width solid $bullet-color;
  // counter-reset: numbered-list;
  margin-left: 10px;
  position: relative;
  list-style-type: none;

  li {
    padding-left: 20px;
    font-size: 13px;
    line-height: 1.2;
    margin-bottom: 15px;
    &:last-child {
      border-left: $bullet-line-width solid $bullet-background-color;
      margin-left: -$bullet-line-width;
    }

    &:before {
      $half-of-font-size: -0.5em;
      background-color: $bullet-color;
      border: $bullet-border-width solid $bullet-background-color;
      border-radius: 50%;
      color: $bullet-background-color;
      content: counter(numbered-list, decimal);
      counter-increment: numbered-list -1;
      display: block;
      font-weight: bold;
      width: $bullet-size + 5px;
      height: $bullet-size + 5px;
      margin-top: $half-of-font-size;
      line-height: $bullet-size;
      position: absolute;
      left: -$bullet-size / 2 - $bullet-line-width / 2 - $bullet-border-width;
      text-align: center;
    }
  }
}
</style>
