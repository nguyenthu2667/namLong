`FontAwesome 5 pro`

fontawesome 5 pro free full pro version with all fonts offline with webfonts version Font 

fontawesome pro 5.8.1 with example of icons
 
 
 
 add one to use your pro FontAwesome 5 
```css
 <link rel="stylesheet" type="text/css" href="css/all.css">
```
 
 full doc https://fontawesome.com/icons?d=gallery


use Brand icon with `fab` class

```html
<i class="fab fa-linux" style="font-size: 48px;"></i>
```

use normal icon with `fal, far, fas` class
```html
<i class="fal fa-chess-clock" style="font-size: 48px;"></i>
<i class="far fa-chess-clock" style="font-size: 48px;"></i>
<i class="fas fa-chess-clock" style="font-size: 48px;"></i>
```

FontAwesome  Pro free download 
