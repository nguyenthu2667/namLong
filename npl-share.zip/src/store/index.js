import auth from './modules/auth'
import map from './modules/map'
import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const store = new Vuex.Store({
  modules: {
    auth,
    map,
  },
})

export default store
