export default {
  state: {
    user: localStorage.getItem('user')
      ? JSON.parse(localStorage.getItem('user'))
      : null,
  },
  getters: {
    currentUser: (state) => state.user,
  },
  mutations: {
    SET_USER(state, user) {
      state.user = user
    },
  },
  actions: {
    setUser({ commit }, user) {
      localStorage.setItem('token', user.Token)
      localStorage.setItem('user', JSON.stringify(user))
      commit('SET_USER', user)
    },
    removeUser({ commit }) {
      localStorage.removeItem('user')
      localStorage.removeItem('token')
      commit('SET_USER', null)
    },
  },
}
