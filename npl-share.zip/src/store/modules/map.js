import Location from '@/directives/locations'

export default {
  state: {
    layers: [],
    typeMap: 'GG',
    centerLocation: Location.hcm, // obj
    markers: [],
    selectedGroupMarkerID: [],
    isResizeMap: false,
  },
  getters: {
    currentLayers: (state) => state.layers,
    typeMap: (state) => state.typeMap,
    centerLocation: (state) => state.centerLocation,
    markers: (state) => state.markers,
    selectedGroupMarkerID: (state) => state.selectedGroupMarkerID,
    isResizeMap: (state) => state.isResizeMap,
  },
  mutations: {
    SET_LAYERS(state, layers) {
      state.layers = layers
    },
    SET_TYPE_MAP(state, typeMap) {
      state.typeMap = typeMap
    },
    SET_MARKERS(state, markers) {
      state.markers = markers
    },
    SET_SELECTED_GROUP_MARKER(state, selected) {
      state.selectedGroupMarkerID = selected
    },
    SET_MAP_RESIZE(state, bool) {
      state.isResizeMap = bool
    },
  },
  actions: {
    async setLayers({ commit }, layers) {
      await commit('SET_LAYERS', layers)
    },
    setTypeMap({ commit }, typeMap) {
      commit('SET_TYPE_MAP', typeMap)
    },
    setMarkers({ commit }, markers) {
      commit('SET_MARKERS', markers)
    },
    setSelectedGroupMarker({ commit }, selected) {
      commit('SET_SELECTED_GROUP_MARKER', selected)
    },
    setIsMapResize({ commit }, bool) {
      commit('SET_MAP_RESIZE', bool)
    },
  },
}
