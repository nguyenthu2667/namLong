import Vue from 'vue'
import VueComp from '@vue/composition-api'
import router from './routes'
import store from './store'
import { BootstrapVue, IconsPlugin } from 'bootstrap-vue'
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'
import VModal from 'vue-js-modal/dist/index.nocss.js'
import VueCarousel from 'vue-carousel'
import 'vue-js-modal/dist/styles.css'
import VueFullscreen from 'vue-fullscreen'
import App from './App.vue' // để sau cùng để đè css boostrap
import Axios from 'axios'
//languages
import VueI18n from 'vue-i18n'
import en from './languages/en.json'
import vn from './languages/vn.json'

Vue.config.productionTip = false
Vue.use(VueCarousel)
Vue.use(BootstrapVue)
Vue.use(IconsPlugin)
Vue.use(VueComp)
Vue.use(VModal)
Vue.use(VueFullscreen)
Vue.use(VueI18n)

const messages = { vn: vn, en: en }
const i18n = new VueI18n({
  locale: localStorage.getItem('currentLanguage'),
  fallbackLocale: 'vn',
  messages,
})

Vue.prototype.$http = Axios

new Vue({
  i18n,
  router,
  store,
  render: (h) => h(App),
}).$mount('#app')
