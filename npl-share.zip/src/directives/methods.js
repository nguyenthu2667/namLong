import moment from 'moment'

const handling = {
  //random
  randomColorHEX: () => `#${Math.floor(Math.random() * 0xffffff).toString(16)}`,

  //so sánh 2 thời gian
  isCompareDateTime: (start, end) => {
    return start < end // true
  },
  //chuyển định dạng tiền việt nam
  convertMoneyVN: (num) => num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','),

  //convert date
  convertDate: (string) =>
    moment(string, "YYYY-MM-DD'T'HH:mm:ss").format('DD/MM/YYYY'),

  convertDateTime: (string) =>
    moment(string, "YYYY-MM-DD'T'HH:mm:ss").format('HH:mm:ss DD/MM/YYYY'),

  convertDateToPicker: (string) =>
    moment(string, 'DD/MM/YYYY').format('YYYY-MM-DD'),

  convertPickerToDate: (string) =>
    moment(string, 'YYYY-MM-DD').format('DD/MM/YYYY'),

  //get date
  getDateNow: () => moment(new Date()).format('DD/MM/YYYY'),
  getDateTimeNow: () => moment(new Date()).format('HH:mm DD/MM/YYYY'),
  getDay: () => moment(new Date()).format('DD'),
  getMonth: () => moment(new Date()).format('MM'),
  getYear: () => moment(new Date()).format('YYYY'),

  //convert data-type
  convertBooleanToBit: (bool) => (bool ? 1 : 0),

  convertBitToBoolean: (bit) => !!bit,
}

export default handling
