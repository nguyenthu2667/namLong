export const LANGUAGE = localStorage.getItem('currentLanguage')
  ? localStorage.getItem('currentLanguage')
  : 'vn'
