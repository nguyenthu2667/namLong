const location = {
  hcm: {
    id: 1,
    zip: null,
    lat: 10.7941878,
    lng: 106.6724396,
    url: 'ho-chi-minh',
    name: 'Hồ Chí Minh',
  },
}
export default location
