<template>
  <footer class="vps-footer">
    <div class="ml-4">
      <hamburger-menu :open="sidebarOpen" @toggle="toggleSidebar" />
    </div>
    <div class="copyright">
      &#9400; {{ new Date().getFullYear() }}, made with
      <span class="vps-heart-char">&#10084;</span>
      by
      <i>
        <b>Nam Long</b>
      </i>
    </div>
  </footer>
</template>

<script>
import HamburgerMenu from '@/components/actions/HamburgerMenu'
import EventBus from '@/utils/EventBus.js'
export default {
  name: 'vps-footer',
  components: {
    HamburgerMenu,
  },
  data() {
    return {
      sidebarOpen: true,
    }
  },
  methods: {
    toggleSidebar() {
      this.sidebarOpen = !this.sidebarOpen
      EventBus.$emit('toggle-sidebar', this.sidebarOpen)
    },
  },
}
</script>

<style lang="scss">
.copyright {
  font-family: 'monospace';
  font-size: 12pt;
}
@mixin pseudoElem($prop) {
  content: '';
  position: absolute;
  top: 4px;
  #{$prop}: 1px;
  border: 2px solid #ff2222;
  opacity: 0;
  border-radius: 50%;
  width: 8px;
  height: 8px;
  -webkit-animation: sonar 1.5s infinite;
  animation: sonar 1.5s infinite;
}
.vps-heart-char {
  color: #ff2222;
  position: relative;
  font-size: 16pt;
  &::before {
    @include pseudoElem(left);
  }
  &::after {
    @include pseudoElem(right);
  }
}
</style>
<style lang="scss">
@import '../styles/_variable.scss';
@import '../styles/_mixins.scss';
.vps-footer {
  @include MediaQuery($mobile) {
    /* display: none !important; */
  }
}
</style>
<style>
.fade-enter-active,
.fade-leave-active {
  transition: opacity 2s;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}
</style>
