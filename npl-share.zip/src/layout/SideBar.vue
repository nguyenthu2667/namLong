<template>
  <aside class="vps-sidebar" :class="{ 'vps-sidebar-closed': !isOpen }">
    <!-- LOGO-USER -->
    <div class="vps-logo">
      <div
        style="height: 80px; background: white; width: 100%; margin-top: -15px;"
        class="sidenav-header d-flex justify-content-center align-items-center"
      >
        <!-- <div style="width: 30%;">
          <hamburger-menu :open="sidebarOpen" @toggle="toggleSidebar" />
        </div> -->
        <div style="width: 35%; margin-left: 10px;">
          <img
            style="height: 40px; width: 100px;"
            src="@/assets/icons/tree/logo.png"
          />
        </div>
        <slot name="toolbar"></slot>
      </div>
    </div>
    <!-- <div class="vps-sidebar-user">
      <div class="vps-sidebar-user--details">
        <div class="vps-sidebar-user-avatar">
          <avatar />
        </div>
      </div>
    </div> -->
    <!-- SLOT-SEARCH -->
    <div
      style="background: whitesmoke; color: black;"
      class="vps-sidebar-search"
    >
      <h5 class="mt-3">
        {{ $t('sidebar.category').toUpperCase() }}
        {{ $t('tree.tree').toUpperCase() }}
      </h5>
    </div>
    <!-- MENU-DYNAMIC -->
    <ul class="vps-sidebar-menu">
      <li class="vps-sidebar-menu-header">
        <div class="parent-menu">
          <h6>
            <b-form-checkbox-group
              id="option-layer"
              v-model="selectedGroupMarkerID"
              name="option-layer"
              stacked
            >
              <template v-for="(group, i) in currentGroupMarker">
                <b-form-checkbox :key="i" class="mb-2" :value="group.id">
                  <div style="margin-top: 5px; color: black;">
                    <!-- <i class="fad fa-tree-alt"></i> -->
                    {{ group.name.toUpperCase() }}
                  </div>
                </b-form-checkbox>
              </template>
            </b-form-checkbox-group>
          </h6>
        </div>
      </li>
    </ul>
    <div class="footer-sidebar">
      <i class="copyright">
        &#9400; {{ new Date().getFullYear() }}, by
        <b>Nam Long</b>
      </i>
      <div><hamburger-menu @toggle="toggleSidebar"></hamburger-menu></div>
    </div>
  </aside>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
import expand from '../directives/expand'
import Icon from '../components/icons'
import Avatar from '../components/Avatar'
import Badge from '../components/Badge'
import EventBus from '../utils/EventBus.js'
import systemAPI from '@/api/systemAPI.js'
import store from '@/store/index'
import mapAPI from '@/api/mapAPI.js'
import HamburgerMenu from '@/components/actions/HamburgerMenu'
// import EventBus from '@/utils/EventBus.js'

export default {
  name: 'side-bar',
  components: {
    Icon,
    Avatar,
    Badge,
    HamburgerMenu,
  },
  directives: {
    expand,
  },
  data() {
    return {
      sidebarOpen: true,
      interval: null,
      isOpen: true,
      expandedCheck: -1,
      layers: [],
      currentGroupMarker: [],
      selectedGroupMarkerID: [],
    }
  },
  computed: {
    ...mapGetters(['currentUser', 'currentLayers']),
  },
  watch: {
    layers(value) {
      this.setLayers(value)
      this.$router.push({
        query: { ...this.$route.query, layers: value },
      })
    },
    currentGroupMarker() {
      this.handleSelectGroupMarker(
        JSON.parse(JSON.stringify(this.currentGroupMarker)),
      )
    },
    selectedGroupMarkerID() {
      this.setSelectedGroupMarker(
        JSON.parse(JSON.stringify(this.selectedGroupMarkerID)),
      )
    },
    //bug-1
    currentLayers() {
      this.layers = this.currentLayers
    },
  },
  async created() {
    this.setLayers(['tree']) // set Default
    await this.setUniqueLayersTwoWay()
    this.layers = this.currentLayers
    await this.getGroupMarker(this.layers)
    this.interval = setInterval(async () => {
      await this.getGroupMarker(this.layers)
    }, 60000)
  },
  mounted() {
    EventBus.$on('toggle-sidebar', (isOpen) => {
      this.isOpen = isOpen
    })
  },
  destroyed() {
    clearInterval(this.interval)
  },
  methods: {
    ...mapActions(['setLayers', 'setSelectedGroupMarker']),
    toggleSidebar() {
      this.sidebarOpen = !this.sidebarOpen
      EventBus.$emit('toggle-sidebar', this.sidebarOpen)
    },
    handleSelectGroupMarker(arr) {
      if (arr?.length > 0) {
        this.selectedGroupMarkerID.length = 0
        arr.forEach((g) => {
          this.selectedGroupMarkerID.push(g.id)
        })
      }
    },
    getGroupMarker(layers) {
      this.currentGroupMarker = []
      if (layers !== undefined) {
        layers.map((layer) => {
          let body = {
            DataCode: layer,
          }
          mapAPI
            .getDataByCODE(body)
            .then((val) => {
              let result = val.status ? val.data : null
              if (result?.length > 0) {
                result[0].DataProperties.forEach((group) => {
                  if (layer === 'tree') {
                    let obj = {
                      id: group.TreeCategoryID, // tương đối
                      name: group.TreeCategoryName,
                      layer: layer,
                    }
                    this.currentGroupMarker.push(obj)
                  }
                })
              }
            })
            .catch((err) => console.log(err))
        })
      }
    },
    setUniqueLayersTwoWay() {
      let arrSideBar = this.currentLayers
      let arrQueryRoute = this.$route.query.layers
        ? this.$route.query.layers
        : []
      let arr = arrSideBar.concat(arrQueryRoute)
      const uniqueLayers = Array.from(new Set(arr))
      this.setLayers(uniqueLayers)
    },
    handleCheckbox(OBJselected) {
      if (OBJselected.isSelected) {
        OBJselected.isSelected = false
        this.mapKeys = this.mapKeys.filter(
          (key) => key.toUpperCase() != OBJselected.to.toUpperCase(),
        )
      } else {
        OBJselected.isSelected = true
        this.mapKeys.push(OBJselected.to.toUpperCase())
      }
    },
    getData() {},
    expandParent(id) {
      let eleDisplayID = document.getElementById(id).style.display
      if (eleDisplayID == 'none') {
        document.getElementById(id).style.display = 'block'
      } else {
        document.getElementById(id).style.display = 'none'
      }
      //handle-router-click
      if (id == '0b' && this.$route.name != 'map') {
        this.$router.push({ name: 'map' })
      }
    },
    expand(id) {
      if (id == this.expandedCheck) {
        this.expandedCheck = -1
      } else {
        this.expandedCheck = id
      }
    },
  },
}
</script>
<style scoped>
.vps-sidebar-user--details {
  display: block;
}
.cus-child:hover {
  color: #ffc107;
  font-weight: bold;
}
</style>
<style>
.fade-enter-active,
.fade-leave-active {
  transition: all 1s;
  max-height: 100%;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  transform: translateY(-100%);

  height: 0;
}
.flip-list-move {
  transition: all 1s;
}
</style>
<style scoped>
.parent-menu {
  width: 100%;
  cursor: pointer;
  color: white;
}
.parent-menu:hover {
  /* color: white; */
}
/* overide-custom */
.vps-sidebar-sub-menu-item {
  margin-left: 43px;
}
.vps-sidebar-sub-menu-item-label::before {
  content: none;
}
.vps-sidebar-menu-header {
  padding: 10px 20px;
}
.vps-sidebar-menu-item-content {
  padding-left: 26px;
}
</style>
