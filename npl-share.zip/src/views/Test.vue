<template>
  <div>
    {{ finalData.length }} || {{ items.length }}
    <b-table :items="finalData"></b-table>
    <div class="main">
      <template v-for="(item, i) in dataDieuKien">
        <div :key="i">
          <span>{{ item.name }}</span>
          <b-dropdown
            :text="dieuKien.find((dk) => dk.value == item.valueDK).name"
            variant="primary"
            class="m-2"
          >
            <template v-for="(dk, index) in dieuKien">
              <b-dropdown-item
                :key="index"
                @click="pushDieuKien(dk.value, item.name)"
              >
                {{ dk.name }}
              </b-dropdown-item>
            </template>
          </b-dropdown>
          <input
            v-show="item.valueDK == '1'"
            v-model="item.value1"
            :key="'a' + i"
          />
          <input
            v-show="item.valueDK == '1'"
            v-model="item.value2"
            :key="'b' + i"
          />
        </div>
        <!-- <div :key="i">
          <span>{{ key }}</span>
          <b-dropdown
            :id="key"
            :text="
              dieuKien.find(
                (dk) =>
                  dk.value ==
                  dataDieuKien.find((item) => item.name == key).valueDK,
              ).name
            "
            variant="primary"
            class="m-2"
          >
            <template v-for="(dk, index) in dieuKien">
              <b-dropdown-item
                :key="index"
                @click="pushDieuKien(dk.value, key)"
              >
                {{ dk.name }}
              </b-dropdown-item>
            </template>
          </b-dropdown>
          <input  :key="i" />
        </div> -->
      </template>
    </div>
    <br />
    dataDieuKien {{ dataDieuKien }} keys {{ keys }}
  </div>
</template>

<script>
export default {
  created() {
    this.finalData = [...this.items]
  },
  data() {
    return {
      finalData: [],
      items: [
        {
          isActive: true,
          age: 40,
          name: 'một',
          date: '03/03/2022',
        },
        {
          isActive: true,
          age: 42,
          name: 'mot',
          date: '01/02/2022',
        },
        { isActive: false, age: 21, name: 'hai', date: '01/03/2022' },
        { isActive: false, age: 89, name: 'hai mot', date: '02/03/2022' },
        { isActive: true, age: 38, name: 'ba', date: '01/05/2022' },
      ],
      dieuKien: [
        {
          name: 'không tìm kiếm',
          value: '0',
        },
        {
          name: 'theo chữ cái',
          value: '1',
        },
        {
          name: 'bằng',
          value: '2',
        },
        {
          name: 'bé hơn',
          value: '3',
        },
        {
          name: 'lớn hơn',
          value: '4',
        },
      ],
      dataDieuKien: [],
    }
  },
  computed: {
    keys() {
      this.dataDieuKien = []
      let keys = Object.keys(this.items[0])
      keys.map((key) => {
        let obj = {
          name: key,
          valueDK: '0',
          value1: null,
          value2: null,
        }
        this.dataDieuKien.push(obj)
      })
      return keys
    },
  },
  watch: {
    dataDieuKien() {
      console.log(1, 'watch-dataDieuKien')
    },
  },
  methods: {
    pushDieuKien(value, key) {
      let obj = this.dataDieuKien.find((item) => item.name == key)
      obj.valueDK = value
      this.filter(this.dataDieuKien)
    },
    filter(arr) {
      console.log(1, 'filter', arr)
      let onFilter = arr.filter((it) => it.valueDK != '0')
      console.log(1, 'onFilter', onFilter)
      let result = []
      result = this.items.filter((item) => item.isActive === true)
      console.log(1, 'result', result)
      this.finalData = []
      this.finalData = result
    },
  },
}
</script>

<style scoped>
.main {
  width: 500px;
  height: 200px;
}
</style>
