<template>
  <div>report-monitor</div>
</template>

<script>
export default {
  name: 'report-monitor',
}
</script>

<style scoped></style>
