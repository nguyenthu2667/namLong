<template>
  <div>
    menu-system
  </div>
</template>

<script>
export default {
  name: 'menu-system',
}
</script>

<style scoped></style>
