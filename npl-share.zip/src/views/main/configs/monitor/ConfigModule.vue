<template>
  <div>dashboard-monitor</div>
</template>

<script>
export default {
  name: 'dashboard-monitor',
}
</script>

<style scoped></style>
