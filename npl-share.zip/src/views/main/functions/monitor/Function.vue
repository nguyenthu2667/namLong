<template>
  <div>function-monitor</div>
</template>

<script>
export default {
  name: 'function-monitor',
}
</script>

<style scoped></style>
