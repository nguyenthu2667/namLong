<template>
  <div>
    import-template
  </div>
</template>

<script>
export default {
  name: 'import-template',
}
</script>

<style lang="scss" scoped></style>
