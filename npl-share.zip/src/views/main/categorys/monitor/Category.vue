<template>
  <div>category-monitor</div>
</template>

<script>
export default {
  name: 'category-monitor',
}
</script>

<style scoped></style>
