<template>
  <div class="tree-feed-back">
    <b-overlay :show="isLoading" rounded="sm">
      <form class="cf">
        <div class="half left cf">
          <input
            type="text"
            id="input-name"
            :placeholder="$t('other.name')"
            v-model="$v.form.name.$model"
            :state="!$v.form.name.$error"
          />
          <div
            v-show="isShow"
            class="text-danger"
            v-if="!$v.form.name.required"
          >
            Không được để trống
          </div>
          <input
            v-model="$v.form.email.$model"
            :state="!$v.form.email.$error"
            type="email"
            id="input-email"
            placeholder="Email"
          />
          <div
            v-show="isShow"
            class="text-danger"
            v-if="!$v.form.email.required"
          >
            Không được để trống
          </div>
          <input
            type="text"
            id="input-phone"
            :placeholder="$t('other.phone')"
            v-model="$v.form.phone.$model"
            :state="!$v.form.phone.$error"
          />
          <div
            v-show="isShow"
            class="text-danger"
            v-if="!$v.form.phone.required"
          >
            Không được để trống
          </div>
          <div v-show="isShow" v-else-if="!$v.form.phone.minLength">
            Số điện thoại ít nhất 10 số!
          </div>
          <div v-show="isShow" v-else-if="!$v.form.phone.maxLength">
            Không hợp lệ!
          </div>
          <div v-show="isShow" v-else-if="!$v.form.phone.rexPhone">
            Không hợp lệ!
          </div>
        </div>
        <div class="half right cf">
          <input
            type="text"
            id="input-title"
            :placeholder="$t('other.title')"
            v-model="$v.form.title.$model"
            :state="!$v.form.title.$error"
          />
          <div
            v-show="isShow"
            class="text-danger"
            v-if="!$v.form.title.required"
          >
            Không được để trống
          </div>
          <textarea
            class="mb-3"
            v-model="$v.form.message.$model"
            :state="!$v.form.message.$error"
            name="message"
            type="text"
            id="input-message"
            :placeholder="$t('other.content')"
          ></textarea>
          <div
            v-show="isShow"
            class="text-danger"
            v-if="!$v.form.message.required"
          >
            Không được để trống
          </div>
        </div>
        <div>
          <b-form-file
            v-model="file"
            :placeholder="$t('other.img') + '..'"
            :browse-text="$t('other.choose')"
          ></b-form-file>
        </div>
        <input
          @click="handleSubmit"
          type="button"
          :value="$t('other.send')"
          id="input-submit"
        />
      </form>
    </b-overlay>
  </div>
</template>

<script>
import { validationMixin } from 'vuelidate'
import commentsAPI from '@/api/commentsAPI.js'

const {
  required,
  maxLength,
  minLength,
  sameAs,
  helpers,
} = require('vuelidate/lib/validators')
const rexPhone = helpers.regex(
  'rexPhone',
  /^(0?)(3[2-9]|5[6|8|9]|7[0|6-9]|8[0-6|8|9]|9[0-4|6-9])[0-9]{7}$/,
)

export default {
  props: ['name', 'data', 'lat', 'long', 'id', '', 'note'],
  name: 'tree-feed-back',
  mixins: [validationMixin],
  data() {
    return {
      isLoading: false,
      isShow: false,
      file: null,
      form: {
        title: '',
        name: '',
        phone: '',
        email: '',
        message: '',
      },
    }
  },
  validations: {
    form: {
      name: {
        required,
      },
      title: {
        required,
      },
      phone: {
        required,
        minLength: minLength(10),
        maxLength: maxLength(10),
        rexPhone,
      },
      email: {
        required,
      },
      message: {
        required,
      },
    },
  },
  methods: {
    handleSubmit() {
      this.isShow = true
      this.$v.form.$touch()
      if (this.$v.form.$anyError) {
        return
      }
      let body = {
        Title: this.form.title,
        Name: this.form.name,
        Phone: this.form.phone,
        Email: this.form.email,
        Content: this.form.message,
        TreeDataCurrentID: this.id,
        Lat: this.lat,
        Long: this.long,
        Images: this.file,
        Note: this.note,
      }
      const formData = new FormData()
      for (const key in body) {
        formData.append(key, body[key])
      }
      commentsAPI
        .add(formData)
        .then((val) => {
          if (val.status) {
            this.makeToast('success', 'THÀNH CÔNG', val.message)
            this.isLoading = true
            setTimeout(() => {
              this.isLoading = false
              this.refeshValue()
            }, 3000)
          } else {
            this.makeToast('danger', 'THẤT BẠI', val.message)
          }
        })
        .catch((err) => {
          this.makeToast('danger', 'THẤT BẠI', err)
        })
    },
    refeshValue() {
      this.form.title = ''
      this.form.name = ''
      this.form.phone = ''
      this.form.email = ''
      this.form.message = ''
      this.file = null
      this.isShow = false
    },
    makeToast(variant = null, title, body) {
      this.$bvToast.toast(body, {
        title: title,
        variant: variant,
        solid: true,
        autoHideDelay: 5000,
      })
    },
  },
}
</script>
<style>
.b-toaster {
  z-index: 99999999 !important;
}
.b-toaster-top-right {
  z-index: 99999999 !important;
}
</style>
<style lang="scss" scoped></style>
<style scoped>
.tree-feed-back {
  font-family: 'Merienda', Helvetica, Arial;
}
ul li {
  list-style-type: none;
}

form {
  /* max-width: 600px; */
  text-align: center;
}
form input,
form textarea {
  border: 0;
  outline: 0;
  padding: 0.6em;
  -moz-border-radius: 8px;
  -webkit-border-radius: 8px;
  border-radius: 8px;
  display: block;
  width: 100%;
  margin-top: 1em;
  -moz-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
  -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
  resize: none;
  border: 1px solid #959595;
}
form input:focus,
form textarea:focus {
  -moz-box-shadow: 0 0px 2px #e74c3c !important;
  -webkit-box-shadow: 0 0px 2px #e74c3c !important;
  box-shadow: 0 0px 2px #e74c3c !important;
}
form #input-submit {
  color: white;
  background: #e74c3c;
  cursor: pointer;
}
form #input-submit:hover {
  -moz-box-shadow: 0 1px 1px 1px rgba(170, 170, 170, 0.6);
  -webkit-box-shadow: 0 1px 1px 1px rgba(170, 170, 170, 0.6);
  box-shadow: 0 1px 1px 1px rgba(170, 170, 170, 0.6);
}
form textarea {
  height: 108px;
}

.half {
  float: left;
  width: 48%;
  margin-bottom: 1em;
}

.right {
  width: 50%;
}

.left {
  margin-right: 2%;
}

@media (max-width: 480px) {
  .half {
    width: 100%;
    float: none;
    margin-bottom: 0;
  }
}
/* Clearfix */
.cf:before,
.cf:after {
  content: ' ';
  /* 1 */
  display: table;
  /* 2 */
}

.cf:after {
  clear: both;
}
</style>
