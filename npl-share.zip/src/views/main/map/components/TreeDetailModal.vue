<template>
  <div>
    <div class="detail-modal p-2" v-if="finalData">
      <div class="header d-flex pr-2 pt-2 pb-2 bg-light">
        <div class="w-100 drag" style="font-size: 1.2rem;">
          <b>
            <i class="fad fa-arrows"></i>
            {{ finalData.StationName.toUpperCase() }}
          </b>
        </div>
        <div class="w-10 text-right" style="position: relative;">
          <b-button
            class="btn-remove"
            style="
              position: absolute;
              top: -8px;
              right: -8px;
              padding: 3px;
              padding-bottom: 0;
              background: #e9ecef;
              border: 0;
            "
            @click="$modal.hide(name)"
          >
            ❌
          </b-button>
        </div>
      </div>
      <div class="content">
        <b-row>
          <b-col lg="12">
            <b-tabs content-class="mt-2" fill>
              <b-tab :title="$t('tab.info').toUpperCase()" active>
                <b-row>
                  <b-col lg="6">
                    <div class="box-height">
                      <div class="box-img">
                        <img
                          style="width: 100%; height: 100%;"
                          src="https://webdev.namlongtekgroup.com/assets/img/tree-2.png"
                        />
                        <span>
                          {{ $t('tree.foliage-width') }}:
                          <b>{{ finalData.FoliageWidth }}</b>
                        </span>
                        <span>
                          {{ $t('tree.tree-height') }}:
                          <b>{{ finalData.TreeHeight }}</b>
                        </span>
                        <span>
                          {{ $t('tree.land-name') }}:
                          <b>{{ finalData.LandName }}</b>
                        </span>
                        <span>
                          {{ $t('tree.tree-width') }}:
                          <b>{{ finalData.TreeWidth }}</b>
                        </span>
                        <span>
                          {{ $t('tree.roots-depth') }}:
                          <b>{{ finalData.RootsDepth }}</b>
                        </span>
                      </div>
                    </div>
                  </b-col>
                  <b-col lg="6">
                    <div class="box-height">
                      <b-row>
                        <b-col lg="4">
                          <b-form-group :label="$t('tree.number')">
                            <b-form-input
                              class="text-left"
                              v-model="finalData.TreeNumber"
                              disabled
                            ></b-form-input>
                          </b-form-group>
                        </b-col>
                        <b-col lg="8">
                          <b-form-group :label="$t('tree.employer')">
                            <b-form-input
                              class="text-left"
                              v-model="finalData.EmployerName"
                              disabled
                            ></b-form-input>
                          </b-form-group>
                        </b-col>
                        <b-col lg="4">
                          <b-form-group :label="$t('tree.category')">
                            <b-form-input
                              class="text-left"
                              v-model="finalData.TreeTypeName"
                              disabled
                            ></b-form-input>
                          </b-form-group>
                        </b-col>
                        <b-col lg="8">
                          <b-form-group :label="$t('tree.status')">
                            <b-form-input
                              :style="'color:' + finalData.StatusColor"
                              class="text-left"
                              v-model="finalData.StatusName"
                              disabled
                            ></b-form-input>
                          </b-form-group>
                        </b-col>
                        <b-col lg="4">
                          <b-form-group :label="$t('tree.year-planting')">
                            <b-form-input
                              class="text-left"
                              :value="finalData.PlantingYear"
                              disabled
                            ></b-form-input>
                          </b-form-group>
                        </b-col>
                        <b-col lg="8">
                          <b-form-group :label="$t('tree.update')">
                            <b-form-input
                              class="text-left"
                              :value="convertDateTime(finalData.UpdateTime)"
                              disabled
                            ></b-form-input>
                          </b-form-group>
                        </b-col>

                        <b-col lg="12">
                          <b-form-group :label="$t('tree.address')">
                            <b-form-input
                              class="text-left"
                              v-model="finalData.FullAddress"
                              disabled
                            ></b-form-input>
                          </b-form-group>
                        </b-col>
                        <b-col lg="12">
                          <b-form-group :label="$t('tree.note')">
                            <b-form-textarea
                              class="text-left"
                              v-model="finalData.Note"
                              disabled
                            ></b-form-textarea>
                          </b-form-group>
                        </b-col>
                      </b-row>
                      <div
                        class="img"
                        v-if="finalData.Images && finalData.Images.length > 0"
                      >
                        <carousel
                          :autoplay="true"
                          :loop="true"
                          :autoplayTimeout="3000"
                          :perPage="finalData.Images.length > 1 ? 2 : 1"
                        >
                          <template v-for="(img, key) in finalData.Images">
                            <slide :key="key">
                              <img
                                :id="'modal-slide-' + key"
                                @click="handleFullscreen('modal-slide-' + key)"
                                style="
                                  width: 100%;
                                  height: 270px;
                                  background: #f3f3f3;
                                "
                                :src="img.Image"
                              />
                            </slide>
                          </template>
                        </carousel>
                      </div>
                      <div v-else class="text-center drag">
                        <img
                          style="width: 100%; height: 270px;"
                          src="https://www.viet247.net/images/noimage_food_viet247.jpg"
                        />
                      </div>
                    </div>
                  </b-col>
                </b-row>
              </b-tab>
              <!-- <b-tab title="LỊCH SỬ">
              <process-step :process="process"></process-step>
            </b-tab> -->
              <!-- <b-tab title="HÌNH ẢNH">
              <div class="box-height">
                <template
                  v-if="finalData.Images && finalData.Images.length > 0"
                >
                  <b-row>
                    <template v-for="(img, i) in finalData.Images">
                      <b-col
                        :key="i"
                        :lg="6"
                        style="height: 350px; margin-bottom: 10px;"
                      >
                        <img
                          style="width: 100%; height: 100%; background: gray;"
                          :src="img.Image"
                        />
                      </b-col>
                    </template>
                  </b-row>
                </template>
                <template v-else>
                  <div class="text-center drag">
                    <img
                      style="width: 100%; height: 100%;"
                      src="https://store.vtctelecom.com.vn/Content/images/no-data.png"
                    />
                  </div>
                </template>
              </div>
            </b-tab> -->
              <b-tab
                :title="
                  $t('tab.progress').toUpperCase() +
                  ', ' +
                  $t('tab.feedback').toUpperCase()
                "
              >
                <b-row>
                  <b-col lg="6" style="max-height: 74vh; overflow: auto;">
                    <process-step :process="process"></process-step>
                  </b-col>
                  <b-col lg="6">
                    <!-- <div class="box-height"> -->
                    <tree-feed-back
                      :id="finalData.StationID"
                      :lat="finalData.Lat"
                      :long="finalData.Long"
                      :note="finalData.Note"
                    ></tree-feed-back>
                    <!-- </div> -->
                  </b-col>
                </b-row>
              </b-tab>
            </b-tabs>
          </b-col>
        </b-row>
      </div>
    </div>
    <div v-else>
      <div class="text-center drag">
        <img
          style="width: 100%; height: 100%;"
          src="https://store.vtctelecom.com.vn/Content/images/no-data.png"
        />
      </div>
    </div>
  </div>
</template>

<script>
import Handling from '@/directives/methods.js'
import { mapGetters, mapActions } from 'vuex'
import TreeFeedBack from '../components/TreeFeedBack'
import ProcessStep from '@/components/process/ProcessStep.vue'

export default {
  props: ['name', 'data', 'reload'],
  name: 'tree-detail-modal',
  components: {
    'tree-feed-back': TreeFeedBack,
    'process-step': ProcessStep,
  },
  data() {
    return {
      finalData: null,
      process: [],
      fullscreen: false,
    }
  },
  computed: {
    ...mapGetters(['markers']),
  },
  watch: {
    markers() {
      this.getData()
    },
  },
  async created() {
    await this.getData()
  },
  methods: {
    handleFullscreen(id) {
      const el = document.getElementById(id)
      el.requestFullscreen()
    },
    getData() {
      if (this.markers?.length > 0 && this.data) {
        this.finalData = this.markers.find(
          (item) => item.StationID === this.data.StationID,
        )

        if (!this.finalData) {
          this.$modal.hide(this.name)
        }
        if (this.finalData.Histories?.length > 0) {
          this.handleProcess(this.finalData.Histories)
        }
      } else {
        this.$modal.hide(this.name)
      }
    },
    handleProcess(arr) {
      this.process.length = 0
      arr.forEach((e) => {
        let step = {
          name: e.RequestName,
          statusID: e.StatusID,
          statusColor: e.statusColor ? e.statusColor : 'black',
          datetime: Handling.convertDateTime(e.StatusTime),
          ...e,
        }
        this.process.push(step)
      })
    },
    handleReload(obj, idModal) {
      this.reload(obj, idModal)
    },
    convertDateTime(string) {
      return Handling.convertDateTime(string)
    },
  },
}
</script>
<style lang="scss" scoped>
@import '@/styles/_variable.scss';
@import '@/styles/_mixins.scss';

.content {
  /* padding-top: 10px; */
  width: 100%;
  /* height: 80vh; */
  overflow: auto;
  @include MediaQuery($mobile) {
    height: 80vh;
  }
}
.box-img {
  height: 100%;
  position: relative;
  & span {
    position: absolute;
    &:nth-child(2) {
      top: 20px;
      left: 5px;
      @include MediaQuery($mobile) {
        top: 8px;
        left: 0px;
      }
    }
    &:nth-child(3) {
      top: 40%;
      right: 5px;
    }
    &:nth-child(4) {
      top: 420px;
      left: 20px;
      @include MediaQuery($mobile) {
        left: 0px;
        top: 320px;
      }
    }
    &:nth-child(5) {
      right: 50px;
      bottom: 254px;
      @include MediaQuery($mobile) {
        right: 15px;
        bottom: 169px;
      }
    }
    &:nth-child(6) {
      color: #cfcece;
      right: 85px;
      bottom: 25px;
      @include MediaQuery($mobile) {
        right: 50px;
      }
    }
  }
}
.btn-remove:hover {
  transform: scale(1.2);
}
.box-height {
  height: 74vh;
  overflow: auto;
}
</style>
<style>
.vm--container {
  z-index: 99999;
}
</style>
<style>
.img .VueCarousel-pagination {
  display: none;
}
</style>
