<template>
  <div class="detail-modal">
    DetailModal {{ name }}
    <b-button @click="$modal.hide(name)">x</b-button>
  </div>
</template>

<script>
export default {
  props: ['name'],
  name: 'detail-modal',
}
</script>

<style lang="scss" scoped>
.detail-modal {
  background: lightblue;
  height: 500px;
}
</style>
