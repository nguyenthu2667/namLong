<template>
  <div class="main-map">
    <div id="mySidenav" class="sidenav" :class="{ 'show-nav': !showNav }">
      <b-row style="width: 100%; margin: 0;">
        <b-col lg="12" style="padding: 0.5rem;">
          <b-form-input
            id="search-input"
            type="search"
            size="sm"
            v-model="searchText"
            :placeholder="$t('other.search') + '..'"
          ></b-form-input>
        </b-col>
        <b-col lg="12" class="text-center">
          <span class="text-muted">
            {{ $t('other.total') }}: {{ searchMarkers.length }}
            {{ $t('other.result') }}
          </span>
        </b-col>
      </b-row>
      <template v-for="(marker, i) in searchMarkers">
        <div :key="i" class="sidenav-item" @click="flyToPoint(marker)">
          <div class="img">
            <carousel
              :autoplay="true"
              :loop="true"
              :autoplayTimeout="3000"
              :perPage="1"
            >
              <template v-for="(link, key) in marker.imgs">
                <slide :key="key">
                  <img
                    style="width: 100%; height: 100px; background: #f3f3f3;"
                    :src="link"
                  />
                </slide>
              </template>
            </carousel>
          </div>
          <div class="info">
            <div style="font-size: 14px;">
              <strong>{{ marker.name }}</strong>
            </div>
            <div style="font-size: 12px;">{{ marker.address }}</div>
            <div :style="'color:' + marker.StatusColor + '; font-size: 13px;'">
              <!-- <i class="fad fa-clock"></i> -->
              {{ marker.StatusName }}
            </div>
          </div>
        </div>
      </template>
    </div>
    <div class="map" id="map">
      <div class="sidenav_btn_default" :class="{ sidenav_btn_after: !showNav }">
        <button
          @click.stop.prevent="() => (showNav = !showNav)"
          class="mb-1 mt-1"
        >
          <i class="fad fa-info"></i>
        </button>
        <button>
          <hamburger-menu @toggle="toggleSidebar">
            <i class="fad fa-exchange"></i>
          </hamburger-menu>
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import moment from 'moment'
import Handling from '@/directives/methods.js'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import 'leaflet.fullscreen/Control.FullScreen'
import 'leaflet.fullscreen/Control.FullScreen.css'
import '@ansur/leaflet-pulse-icon/dist/L.Icon.Pulse'
import '@ansur/leaflet-pulse-icon/dist/L.Icon.Pulse.css'
import 'leaflet.markercluster/dist/MarkerCluster.css'
import 'leaflet.markercluster/dist/MarkerCluster.Default.css'
import 'leaflet.markercluster/dist/leaflet.markercluster'
import 'leaflet.markercluster/dist/leaflet.markercluster-src'
import { mapGetters, mapActions } from 'vuex'
import mapAPI from '@/api/mapAPI.js'
//module
import DetailModal from './components/DetailModal'
import TreeDetailModal from './components/TreeDetailModal'
import TreeBlue from '../../../assets/icons/tree/tree.png'
import TreeRed from '../../../assets/icons/tree/tree-orange.png'
import HamburgerMenu from '@/components/actions/HamburgerMenu'
import EventBus from '@/utils/EventBus.js'

export default {
  name: 'map-main',
  components: {
    DetailModal,
    TreeDetailModal,
    HamburgerMenu,
  },
  data() {
    return {
      sidebarOpen: true,
      interval: null,
      currentLocation: {
        id: 0,
        zip: null,
        lat: 10.7941878,
        lng: 106.6724396,
        url: 'current',
        name: 'Vị Trí Hiện Tại',
      },
      showNav: true,
      map: null,
      idModal: 0,
      dataLayers: [],
      searchMarkers: [],
      searchText: '',
      currentMarkers: [],
    }
  },
  computed: {
    ...mapGetters([
      'typeMap',
      'centerLocation',
      'markers',
      'selectedGroupMarkerID',
      'isResizeMap',
    ]),
  },
  watch: {
    showNav() {
      this.cssControlMap(this.showNav)
    },
    $route(to, from) {
      if (!to.query) {
        //query-null => reload
        location.reload()
      }
      this.getDataByLayers(to.query.layers)
    },
    currentMarkers() {
      this.setMarkers(this.currentMarkers)
      this.searchMarkers.length = 0
      this.searchMarkers = [...this.currentMarkers]
    },
    searchText(to, from) {
      if (to && to !== '') {
        let array = []
        let regex = new RegExp(to, 'i')
        this.currentMarkers.forEach((val) => {
          if (
            val.name.search(regex) !== -1 ||
            val.address.search(regex) !== -1
          ) {
            array.push(val)
          }
        })
        this.searchMarkers = array
      } else {
        this.searchMarkers = []
      }
      if (to === '') {
        this.searchMarkers = [...this.currentMarkers]
      }
    },
    selectedGroupMarkerID(to, form) {
      this.getDataByLayers(this.$route.query.layers)
    },
  },
  async created() {
    this.$router.replace({ name: 'map' }).catch(() => {}) // fix nav..warning
    await this.handleDefault()
  },
  async mounted() {
    await this.initMap(this.typeMap)
    await this.handleLocation()
    await this.cssControlMap(true)
  },

  methods: {
    ...mapActions(['setMarkers', 'setLayers']),
    //handle-sidebar
    toggleSidebar() {
      this.sidebarOpen = !this.sidebarOpen
      EventBus.$emit('toggle-sidebar', this.sidebarOpen)
    },
    //
    cssControlMap(bool) {
      var ele = document.querySelector('.leaflet-left')
      if (bool) {
        ele.classList.add('myleft')
      } else {
        ele.classList.remove('myleft')
      }
    },

    flyToPoint(item) {
      this.map.flyTo([item.lat, item.long], 18, {
        animate: true,
        duration: 2,
      })
    },
    reloadData(obj, idModal) {
      console.log(1, 'reloadData', obj, idModal)
    },
    async getDataByLayers(layers) {
      this.map.invalidateSize()
      if (layers) {
        const result = await Promise.all(
          layers.map((layer) => {
            return new Promise((resolve, reject) => {
              mapAPI
                .getDataByCODE({ DataCode: layer })
                .then((res) => {
                  return new Promise(() => {
                    resolve(res.data[0])
                    reject({})
                  })
                })
                .catch((err) => {
                  resolve({})
                })
            })
          }),
        )
        // this.dataLayers = result
        if (result) {
          this.currentMarkers = []
          this.removeLayerAll()
          //!!!warning
          result.map((l) => {
            this.pushMakers(l)
          })
        } else {
          console.log('result-undefide')
        }
      } else {
        console.log('layers-undefinedd')
        //bug-1
        this.setLayers([])
      }
    },
    handleDefault() {
      this.$router.push({
        path: this.$route.fullPath,
        query: {
          location: this.currentLocation.url,
          type: this.typeMap,
          ...this.$route.query,
        },
      })
    },
    showModal(obj, id, typeMarker) {
      const props = {
        name: 'modal-' + id,
        data: obj,
        reload: this.reloadData,
      }
      const options = {
        name: 'modal-' + id,
        draggable: '.drag',
        clickToClose: false,
        reset: true,
        classes: 'cus-modal',
        adaptive: true,
        height: 'auto',
        width: '60%',
      }
      const events = {
        opened: () => this.handleOpenModal(),
        closed: () => this.handleCloseModal(),
      }
      if (typeMarker === 'TREE') {
        this.$modal.show(TreeDetailModal, props, options, events)
      } else {
        this.$modal.show(DetailModal, props, options, events)
      }
    },
    handleOpenModal(id = null) {
      console.log(1, 'handleOpenModal', id)
    },
    handleCloseModal(id = null) {
      console.log(1, 'handleCloseModal', id)
    },
    initMap(type) {
      let mapDefault, urlMap
      switch (type) {
        case '2D':
          console.log('loading..2D')
          break
        default:
          urlMap = 'https://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}'
          mapDefault = L.tileLayer(urlMap, {
            type: 'MAP',
            minZoom: 1,
            maxZoom: 20,
            subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
          })
          break
      }
      this.map = L.map('map', {
        center: this.currentLocation,
        zoom: 11,
        layers: mapDefault,
        fullscreenControl: true,
      })
      L.control.scale({ position: 'bottomright' }).addTo(this.map)
      this.map.invalidateSize()
    },
    removeLayerAll() {
      this.map.eachLayer((l) => {
        if (l.options.type !== 'MAP') {
          this.map.removeLayer(l)
        }
      })
    },
    pushMakers(layer) {
      if (!layer.DataTypeName) return
      if (layer.DataTypeName.toUpperCase() === 'TREE') {
        if (layer.DataProperties?.length > 0) {
          layer.DataProperties.forEach((region) => {
            const isCheck = this.selectedGroupMarkerID.includes(
              region.TreeCategoryID,
            )
            if (isCheck === true) {
              if (region.Trees?.length > 0) {
                let markers = region.Trees
                let group = L.markerClusterGroup({
                  spiderfyOnMaxZoom: false,
                  showCoverageOnHover: false,
                  zoomToBoundsOnClick: false,
                  disableClusteringAtZoom: 18,
                  type: 'MARKER',
                  typeMarker: layer.DataTypeName,
                  id: region.TreeCategoryID,
                  name: region.TreeCategoryName,
                  ...region,
                })
                markers.forEach((m) => {
                  let icon = this.customIcon(
                    m,
                    layer.DataTypeName.toUpperCase(),
                  )
                  let marker = L.marker([m.Lat, m.Long], {
                    icon: icon,
                    type: 'MARKER',
                    id: m.StationID,
                    groupID: region.TreeCategoryID,
                    typeMarker: layer.DataTypeName,
                    lat: m.Lat,
                    long: m.Long,
                    img: m.TreeImage,
                    name: m.StationName,
                    address: m.FullAddress,
                    datetime: Handling.convertDateTime(m.UpdateTime),
                    imgs: m.Images.map((img) => img.Image),
                    ...m,
                  })
                  let markerOBJ = {
                    type: 'MARKER',
                    id: m.StationID,
                    groupID: region.TreeCategoryID,
                    typeMarker: layer.DataTypeName,
                    lat: m.Lat,
                    long: m.Long,
                    img: m.TreeImage,
                    name: m.StationName,
                    address: m.FullAddress,
                    datetime: Handling.convertDateTime(m.UpdateTime),
                    imgs: m.Images.map((img) => img.Image),
                    ...m,
                  }
                  let templateHTML = this.customHTML(
                    m,
                    layer.DataTypeName.toUpperCase(),
                  )
                  let popup = L.popup({
                    closeButton: false,
                  }).setContent(templateHTML)
                  marker.bindPopup(popup)
                  marker.on('mouseover', function (e) {
                    marker.openPopup()
                  })
                  marker.on('mouseout', function (e) {
                    marker.closePopup()
                  })
                  marker.on('click', () =>
                    this.showModal(
                      m,
                      `${layer.DataTypeName}-${m.StationID}`,
                      layer.DataTypeName.toUpperCase(),
                    ),
                  )
                  this.currentMarkers.push(markerOBJ)
                  group.addLayer(marker)
                })
                group.addTo(this.map)
              }
            }
          })
        }
      }
    },
    customIcon(obj, typeMarker) {
      let icon = L.icon({
        iconUrl: 'https://img.icons8.com/material-rounded/344/marker.png',
        iconSize: [30, 40],
      })
      if (typeMarker === 'TREE') {
        let link = obj.StatusID == 1047 ? TreeRed : TreeBlue
        icon = L.icon({
          iconUrl: link,
          iconSize: [30, 30],
        })
      }

      return icon
    },
    customHTML(obj, typeMarker) {
      let html = ``
      if (typeMarker === 'TREE') {
        html = `<div style="display: flex; font-family: 'Merienda';">
              <img
                style="width: 150px; height: 200px;"
                src="${obj.TreeImage}"
              />
              <div style="background:#f7f7f7" class="pl-2 pr-2">
                <p  style="font-size: 15px; line-height: 1.3;">
                  <strong>${obj.StationName.toUpperCase()}</strong>
                </p>
                <p
                  class="font-italic"
                  style="font-size: 14px; margin-top: -10px; line-height: 1.3;"
                >
                  ${obj.FullAddress}
                </p>
                <p
                  class="pl-3 pr-3 font-italic"
                  style="font-size: 12px; margin-top: -10px; line-height: 1.3;"
                >
                  <div>Cập nhật lúc:</div>
                  <span class="text-danger font-weight-bold">${Handling.convertDateTime(
                    obj.UpdateTime,
                  )}</span>
                </p>
              </div>
            </div>`
      }
      return html
    },
    handleLocation() {
      const success = (position) => {
        const latitude = position.coords.latitude
        const longitude = position.coords.longitude
        if (latitude && longitude) {
          this.currentLocation.lat = latitude
          this.currentLocation.lng = longitude
        } else {
          this.currentLocation = this.centerLocation
        }
      }
      const error = (err) => {
        this.currentLocation = this.centerLocation
        console.log('FAIL LOCATION CURRENT => ', err, this.currentLocation)
      }
      navigator.geolocation.getCurrentPosition(success, error)
    },
  },
}
</script>

<style lang="scss" scoped>
#map {
  width: 100%;
  height: 99vh;
  background-color: #bbe2c6;
  margin-top: -70px;
}
.show-nav {
  display: none;
}
.sidenav {
  font-family: 'Merienda';
  position: absolute;
  /* margin-top: 20px; */
  margin-top: -58px;
  padding: 5px;
  z-index: 999;
  background: white;
  width: 280px;
  /* height: 93%; */
  height: 105%;
  border: 1px solid #dddada;
  left: 12px;
  top: 0;
  /* box-shadow: 0 4px 8px 0 rgba(0 0 0 / 20%), 0 6px 20px 0 rgba(0 0 0 / 19%); */
  overflow: auto;
  & .sidenav-item {
    height: 100px;
    margin: 6px;
    display: flex;
    & .img {
      width: 35%;
      background: gray;
    }
    & .info {
      width: 65%;
      padding: 5px;
      overflow: auto;
      &:hover {
        background: #f7f7f7;
        cursor: pointer;
      }
    }
  }
}
.map {
  position: relative;
  .sidenav_btn_default {
    position: absolute;
    z-index: 999;
    font-size: 18px;
    top: 94px;
    left: 281px;
    width: 32px;
    border-radius: 2px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    & button {
      width: 32px;
      border-radius: 2px;
      border: 1px solid #dddada;
      background: white;
    }
    & :hover {
      background: #f7f7f7;
    }
  }
  .sidenav_btn_after {
    left: 11px !important;
    top: 105px;
  }
}
</style>
<style>
.vm--overlay {
  width: 0;
  height: 0;
}
.vm--container {
  width: 0;
  height: 0;
}
.myleft {
  left: 270px !important;
  color: red;
  top: -10px;
}
</style>
<style>
.img .VueCarousel-pagination {
  display: none;
}
</style>
