<template>
  <div>
    <div id="example-2">
      <button @click="show = !show">Kích hoạt</button>
      <transition name="bounce">
        <p v-if="show">Cân đẩu vân</p>
      </transition>
    </div>
  </div>
</template>

<script>
import SelectBox from '@/components/selects/SelectSingleBT.vue'
import SemiSingleCustom from '@/components/charts/SemiSingleCustom.vue'
import Handling from '@/directives/methods.js'

export default {
  components: {
    SelectBox,
    SemiSingleCustom,
  },
  name: 'dashboard-monitor',
  data() {
    return {
      show: true,
      color: 'red',
      num: 123456,
      color: Handling.randomColorHEX(),
    }
  },
  computed: {
    userStyle() {
      return {
        '--color': this.color,
      }
    },
  },
  methods: {
    convertNumber(number) {
      return Handling.convertMoneyVN(number)
    },
  },
}
</script>
<style lang="scss" scoped>
@import '@/styles/_variable.scss';
@import '@/styles/_mixins.scss';

.box {
  color: $cl-red-type9;
  width: $mobile;
}
#footer {
  background: lightblue;
  @include MediaQuery($mobile) {
    background: red;
  }
}
</style>
<style scoped>
.bounce-enter-active {
  animation: bounce-in 0.5s;
}
.bounce-leave-active {
  animation: bounce-in 0.5s reverse;
}
@keyframes bounce-in {
  0% {
    transform: scale(0);
  }
  50% {
    transform: scale(1.5);
  }
  100% {
    transform: scale(1);
  }
}
</style>
