<template>
  <div>dashboard-aqua</div>
</template>

<script>
export default {
  name: 'dashboard-aqua',
}
</script>

<style scoped></style>
