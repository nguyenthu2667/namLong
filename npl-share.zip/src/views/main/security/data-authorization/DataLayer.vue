<template>
  <div>
    data-layer
  </div>
</template>

<script>
export default {
  name: 'data-layer',
}
</script>

<style lang="scss" scoped></style>
