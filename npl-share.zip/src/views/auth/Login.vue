<template>
  <div class="view-full">
    <div class="box-parent">
      <div class="box-chil">
        <div class="login">
          <form @submit.prevent.stop="handleSubmit">
            <h1>LOGIN</h1>
            <div class="social-container">
              <a href="#"><i class="fab fa-facebook-f"></i></a>
              <a href="#"><i class="fab fa-google"></i></a>
              <a href="#"><i class="fab fa-github"></i></a>
            </div>
            <span>or use your email for registration</span>
            <input
              type="text"
              placeholder="Username"
              v-model="$v.form.username.$model"
              :state="!$v.form.username.$error"
            />
            <span class="text-danger" v-if="!$v.form.username.required">
              không được trống !
            </span>
            <span class="text-danger" v-else-if="!$v.form.username.minLength">
              sai giới hạn !
            </span>
            <input
              type="password"
              placeholder="Password"
              v-model="$v.form.password.$model"
              :state="!$v.form.password.$error"
            />
            <span class="text-danger" v-if="!$v.form.password.required">
              không được trống !
            </span>
            <span class="text-danger" v-else-if="!$v.form.password.minLength">
              sai giới hạn !
            </span>
            <div
              style="width: 100%;"
              class="d-flex justify-content-between main-parent"
            >
              <div class="select-chil_main">
                <div
                  v-if="list && value"
                  class="aselect"
                  :data-value="value"
                  :data-list="list"
                >
                  <div class="selector" @click.stop="toggle()">
                    <div class="label">
                      <span>
                        <img
                          style="width: 30px; height: 25px;"
                          :src="value.icon"
                          alt="icon"
                        />
                        {{ value.label.toUpperCase() }}
                      </span>
                    </div>
                    <div class="arrow" :class="{ expanded: visible }"></div>
                    <div :class="{ hidden: !visible, visible }">
                      <ul>
                        <li
                          :class="{ current: item === value }"
                          v-for="(item, i) in list"
                          @click.stop="select(item)"
                          :key="i"
                        >
                          <img
                            style="width: 30px; height: 25px;"
                            :src="item.icon"
                            alt="icon"
                          />
                          {{ item.label.toUpperCase() }}
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              <button id="btn-chil_main">
                <template v-if="isLoading">
                  <b-overlay :show="true" rounded="sm" style="height: 44px;" />
                </template>
                <template v-else>
                  ĐĂNG NHẬP
                </template>
              </button>
            </div>
          </form>
        </div>
      </div>
      <div id="box-right-id" class="box-chil">
        <div class="banner">
          <div class="pt-5">
            <h1>Hello, Friend!</h1>
            <p>Enter your personal details and start journey with us</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
import { LANGUAGE } from '@/directives/contants'
import methods from '@/directives/methods'
import systemAPI from '@/api/systemAPI.js'
import userAPI from '@/api/userAPI.js'
import { validationMixin } from 'vuelidate'

const { required, maxLength, minLength } = require('vuelidate/lib/validators')

export default {
  mixins: [validationMixin],
  validations: {
    form: {
      username: {
        minLength: minLength(3),
        required,
      },
      password: {
        required,
        maxLength: maxLength(16),
        minLength: minLength(3),
      },
    },
  },
  data() {
    return {
      isLoading: false,
      keyLanguage: LANGUAGE,
      value: null,
      list: [],
      visible: false,
      form: {
        username: '',
        password: '',
      },
    }
  },
  computed: {
    ...mapGetters(['currentUser']),
  },
  watch: {
    value() {
      localStorage.setItem('currentLanguage', this.value.id)
    },
    currentUser(val) {
      if (val) {
        setTimeout(() => {
          this.$router.push('/')
        }, 500)
      }
    },
  },
  methods: {
    ...mapActions(['setUser']),
    showToast(variant = null, title, body) {
      this.$bvToast.toast(body, {
        title: title,
        variant: variant,
        solid: true,
        autoHideDelay: 3000,
      })
    },
    handleSubmit() {
      this.isLoading = true
      if (this.$v.$anyError == true) {
        this.showToast('danger', 'THẤT BẠI', 'Tài khoản không hợp lệ !')
        this.isLoading = false
      } else {
        let body = {
          UserName: this.form.username,
          UserPassword: this.form.password,
        }
        userAPI
          .login(body)
          .then((val) => {
            let result = val.status ? val.data : null
            if (result) {
              this.setUser(result[0])
              this.showToast('success', 'THÀNH CÔNG', val.message)
              this.isLoading = false
            } else {
              localStorage.removeItem('user')
              localStorage.removeItem('token')
              this.showToast('danger', 'THẤT BẠI', val.message)
              this.isLoading = false
            }
          })
          .catch((err) => console.log(err))
      }
    },
    getDataOptionLanguage() {
      let array = []
      systemAPI
        .getLanguages()
        .then((res) => {
          let result = res.status ? res.data : null
          if (result?.length > 0) {
            this.list.length = 0
            result.forEach((e) => {
              let obj = {
                id: e.Code,
                label: e.LanguageName,
                icon: e.Icon,
              }
              this.list.push(obj)
              if (obj.id == this.keyLanguage) {
                this.value = obj
              }
            })
          }
        })
        .catch((err) => {
          console.log(err)
        })
      return array
    },
    toggle() {
      this.visible = !this.visible
    },
    select(option) {
      this.value = option
    },
  },
  async created() {
    if (this.currentUser) {
      this.$router.push('/')
      return
    }
    await this.getDataOptionLanguage()
  },
}
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css?family=Montserrat:400,800');
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
.view-full {
  display: grid;
  height: 100vh;
  background-image: url('../../assets/img/bg-login4.gif');
  background-repeat: no-repeat;
  background-size: cover;
}
.box-parent {
  margin: auto;
  width: 80%;
  height: 60vh;
  background: #ff416c;
  display: flex;
}
.box-chil {
  width: 100%;
}
.container {
  background-color: #fff;
  border-radius: 10px;
}
/* left */
.login {
  background: lightgreen;
  height: 100%;
  box-shadow: 0 14px 28px rgba(0, 0, 0, 0.25), 0 10px 10px rgba(0, 0, 0, 0.22);
}

.social-container {
  margin: 20px 0;
}

.social-container a {
  border: 1px solid #dddddd;
  border-radius: 50%;
  display: inline-flex;
  justify-content: center;
  align-items: center;
  margin: 0 5px;
  height: 40px;
  width: 40px;
}
.social-container a:first-child {
  background: #2962ff;
  color: white;
}
.social-container a:nth-child(2) {
  background: #fbbc05;
}
.social-container a:last-child {
  background: #f4cbb2;
}
/* right */
.banner {
  text-align: center;
  background: lightpink;
  height: 100%;
  box-shadow: 0 14px 28px rgba(0, 0, 0, 0.25), 0 10px 10px rgba(0, 0, 0, 0.22);
  color: white;
  background: #ff416c;
  background: -webkit-linear-gradient(to right, #ff4b2b, #ff416c);
  background: linear-gradient(to right, #ff4b2b, #ff416c);
}

h1 {
  font-weight: bold;
  margin: 0;
}

h2 {
  text-align: center;
}

p {
  font-size: 14px;
  font-weight: 100;
  line-height: 20px;
  letter-spacing: 0.5px;
  margin: 20px 0 30px;
}

span {
  font-size: 12px;
}

a {
  color: #333;
  font-size: 14px;
  text-decoration: none;
  margin: 15px 0;
}

button {
  min-width: 160px;
  border-radius: 5px;
  border: 1px solid #ff4b2b;
  background-color: #ff4b2b;
  color: #ffffff;
  font-size: 12px;
  font-weight: bold;
  padding: 12px 45px;
  letter-spacing: 1px;
  text-transform: uppercase;
  transition: transform 80ms ease-in;
}

button:active {
  transform: scale(0.95);
}

button:focus {
  outline: none;
}

button.ghost {
  background-color: transparent;
  border-color: #ffffff;
}

form {
  background-color: #ffffff;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  padding: 0 50px;
  height: 100%;
  text-align: center;
}

input {
  background-color: #eee;
  border: none;
  padding: 12px 15px;
  margin: 8px 0;
  width: 100%;
}
@media screen and (max-width: 1200px) {
  /* larg creen */
}
@media screen and (max-width: 992px) {
  /* laptop */
}
@media screen and (max-width: 768px) {
  /* tablet */
}
@media screen and (max-width: 600px) {
  #box-right-id {
    display: none;
  }
  .main-parent {
    width: 100%;
    flex-wrap: wrap-reverse;
  }
  #btn-chil_main {
    width: inherit;
    margin-bottom: 10px;
  }
  .select-chil_main {
    width: 100%;
    text-align: -webkit-center;
  }
  .aselect {
    width: inherit !important;
  }
}
</style>
<style lang="scss" scoped>
.aselect {
  cursor: pointer;
  width: 160px;
  /* margin: 20px auto; */
  .selector {
    border: 1px solid gainsboro;
    background: #f8f8f8;
    position: relative;
    z-index: 1;
    .arrow {
      position: absolute;
      right: 10px;
      top: 40%;
      width: 0;
      height: 0;
      border-left: 7px solid transparent;
      border-right: 7px solid transparent;
      border-top: 10px solid #888;
      transform: rotateZ(0deg) translateY(0px);
      transition-duration: 0.3s;
      transition-timing-function: cubic-bezier(0.59, 1.39, 0.37, 1.01);
    }
    .expanded {
      transform: rotateZ(180deg) translateY(2px);
    }
    .label {
      display: block;
      padding: 4px 7px;
      font-size: 16px;
      color: #888;
      text-align: start;
      margin-top: 7px;
    }
  }
  ul {
    width: 100%;
    list-style-type: none;
    padding: 0;
    margin: 0;
    font-size: 16px;
    border: 1px solid gainsboro;
    position: absolute;
    z-index: 1;
    background: #fff;
    text-align: start;
  }
  li {
    padding: 5px;
    color: #666;
    font-size: 12px;
    &:hover {
      color: white;
      background: seagreen;
    }
  }
  .current {
    background: #eaeaea;
  }
  .hidden {
    visibility: hidden;
  }
  .visible {
    visibility: visible;
  }
}
</style>
